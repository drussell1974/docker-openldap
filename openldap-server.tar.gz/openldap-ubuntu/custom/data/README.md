contains ldap data - can be mapped to a volume to persist the 'ldap directory' on the docker host

